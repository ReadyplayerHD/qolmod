# QoL Mod für Minecraft 1.20.4 (Fabric)

Quality-of-Life Mod mit 10 Features und In-Game-Konfigurationsmenü (Taste `P`).

## ✨ Features

### 🖥️ HUD
| Feature | Beschreibung |
|---|---|
| **Koordinaten-HUD** | X/Y/Z + Himmelsrichtung oben links |
| **Statuseffekt-HUD** | Aktive Tränke mit verbleibender Zeit |

### 🎮 Komfort
| Feature | Taste | Beschreibung |
|---|---|---|
| **Fullbright** | `G` | Volle Helligkeit überall |
| **Zoom** | `C` halten | OptiFine-ähnlicher Zoom |
| **Schnelles Essen** | – | Halbe Essenszeit (0,8s statt 1,6s) |
| **Auto-Step** | – | 1 Block ohne Springen überwinden |

### ⚔️ Gameplay
| Feature | Beschreibung |
|---|---|
| **Tree Feller** | Axt fällt den ganzen Baum (max. 150 Stämme, Haltbarkeit verbraucht) |
| **Auto-Replant** | Reife Ernte (Weizen/Karotten/Kartoffeln/Rüben) pflanzt sich neu |
| **Langsamer Hunger** | 50% weniger Erschöpfung durch Laufen/Springen |
| **Weiche Landung** | Fallschaden max. 10 Herzen; beim Schleichen halbiert |

## 🔧 Build & Installation

```bash
# 1. Gradle Wrapper generieren (einmalig)
gradle wrapper --gradle-version 8.4

# 2. Kompilieren
./gradlew build
# → build/libs/qolmod-1.0.0.jar
```

**Installieren:**
- [Fabric Loader 0.15.6](https://fabricmc.net/use/installer/) für Minecraft 1.20.4
- [Fabric API](https://modrinth.com/mod/fabric-api/versions?gameVersions=1.20.4) herunterladen
- Beide `.jar`-Dateien → `.minecraft/mods/`

## 📁 Struktur

```
src/main/java/com/example/qolmod/
├── QolMod.java           ← Server-Entrypoint (Tree Feller & Auto-Replant Events)
├── QolModClient.java     ← Client: HUD, Keybinds, Zoom, Fullbright
├── ModConfig.java        ← Einstellungen (JSON)
├── ModConfigScreen.java  ← In-Game-Menü (Taste P)
├── TreeFeller.java       ← Baum-Fäll-Logik
├── AutoReplant.java      ← Auto-Anpflanz-Logik
└── mixin/
    ├── PlayerEntityMixin.java    ← Auto-Step
    ├── ItemStackMixin.java       ← Schnelles Essen
    ├── HungerManagerMixin.java   ← Langsamer Hunger
    ├── LivingEntityMixin.java    ← Weiche Landung
    └── GameRendererMixin.java    ← Zoom (FOV)
```
