package com.example.qolmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.Collection;

@Environment(EnvType.CLIENT)
public class QolModClient implements ClientModInitializer {

    public static boolean isZooming  = false;
    public static double  savedGamma = 1.0;

    private static KeyBinding menuKey;
    private static KeyBinding fullbrightKey;
    private static KeyBinding zoomKey;

    private static final int COLOR_VALUE    = 0xFFFFFFFF;
    private static final int COLOR_LABEL    = 0xFFAAAAAA;
    private static final int COLOR_POSITIVE = 0xFF55FF55;
    private static final int COLOR_NEGATIVE = 0xFFFF5555;

    @Override
    public void onInitializeClient() {
        registerKeybinds();
        registerTickEvents();
        registerHud();
    }

    private void registerKeybinds() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.qolmod.menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_P,
                "category.qolmod.general"
        ));
        fullbrightKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.qolmod.fullbright",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_G,
                "category.qolmod.general"
        ));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.qolmod.zoom",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_C,
                "category.qolmod.general"
        ));
    }

    private void registerTickEvents() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ModConfig cfg = ModConfig.get();

            // P → Einstellungsmenü
            if (menuKey.wasPressed() && client.player != null) {
                client.setScreen(new ModConfigScreen(null));
            }

            // G → Fullbright Toggle
            if (fullbrightKey.wasPressed() && client.player != null) {
                cfg.fullbright = !cfg.fullbright;
                ModConfig.save();
                if (cfg.fullbright) {
                    savedGamma = client.options.getGamma().getValue();
                    client.options.getGamma().setValue(16.0);
                } else {
                    client.options.getGamma().setValue(savedGamma);
                }
                client.player.sendMessage(
                        Text.literal("§eVollhelligkeit: " + (cfg.fullbright ? "§aAN" : "§cAUS")), true);
            }

            // C → Zoom
            isZooming = cfg.zoom && InputUtil.isKeyPressed(
                    client.getWindow().getHandle(),
                    zoomKey.getDefaultKey().getCode()
            );
        });
    }

    private void registerHud() {
        HudRenderCallback.EVENT.register((DrawContext ctx, float tickDelta) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null || client.options.debugEnabled) return;
            if (client.currentScreen != null) return;

            ModConfig cfg = ModConfig.get();
            TextRenderer tr = client.textRenderer;
            int x = 4, y = 4;

            // Koordinaten-HUD
            if (cfg.coordinatesHud) {
                var pos = client.player.getBlockPos();
                ctx.drawText(tr, Text.literal("§7X: §f" + pos.getX()), x, y,      COLOR_VALUE, true);
                ctx.drawText(tr, Text.literal("§7Y: §f" + pos.getY()), x, y + 10, COLOR_VALUE, true);
                ctx.drawText(tr, Text.literal("§7Z: §f" + pos.getZ()), x, y + 20, COLOR_VALUE, true);
                ctx.drawText(tr, Text.literal("§7Richtung: §e" + facing(client.player.getYaw())),
                        x, y + 30, COLOR_VALUE, true);
                y += 44;
            }

            // Indikatoren
            if (cfg.fullbright) {
                ctx.drawText(tr, Text.literal("§e☀ Fullbright"), x, y, COLOR_VALUE, true);
                y += 10;
            }
            if (isZooming) {
                ctx.drawText(tr, Text.literal("§b⊕ Zoom"), x, y, COLOR_VALUE, true);
                y += 10;
            }

            // Statuseffekt-HUD
            if (cfg.statusEffectHud) {
                Collection<StatusEffectInstance> effects = client.player.getStatusEffects();
                if (!effects.isEmpty()) {
                    y += 4;
                    ctx.drawText(tr, Text.literal("§7── Effekte ──"), x, y, COLOR_LABEL, true);
                    y += 10;
                    for (StatusEffectInstance eff : effects) {
                        StatusEffect type = eff.getEffectType();
                        boolean bad = !type.isBeneficial();
                        int amp = eff.getAmplifier() + 1;
                        String line = (bad ? "§c✗" : "§a✔") + " §f"
                                + type.getName().getString()
                                + (amp > 1 ? " " + roman(amp) : "")
                                + " §7(" + duration(eff.getDuration()) + ")";
                        ctx.drawText(tr, Text.literal(line), x, y, bad ? COLOR_NEGATIVE : COLOR_POSITIVE, true);
                        y += 10;
                    }
                }
            }
        });
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private static String facing(float yaw) {
        yaw = ((yaw % 360) + 360) % 360;
        if (yaw < 22.5  || yaw >= 337.5) return "Süd ↓";
        if (yaw < 67.5)  return "SW ↙";
        if (yaw < 112.5) return "West ←";
        if (yaw < 157.5) return "NW ↖";
        if (yaw < 202.5) return "Nord ↑";
        if (yaw < 247.5) return "NO ↗";
        if (yaw < 292.5) return "Ost →";
        return "SO ↘";
    }

    private static String duration(int ticks) {
        int s = ticks / 20;
        return s >= 60 ? (s / 60) + ":" + String.format("%02d", s % 60) : s + "s";
    }

    private static String roman(int n) {
        String[] r = {"","I","II","III","IV","V","VI","VII","VIII","IX","X"};
        return (n >= 1 && n <= 10) ? r[n] : String.valueOf(n);
    }
}
