package com.example.qolmod.mixin;

import com.example.qolmod.QolModClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Zoom: Setzt FOV auf 10° wenn C gehalten wird und Zoom aktiv ist.
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {

    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void qolmod$zoom(Camera camera, float tickDelta, boolean changingFov,
                             CallbackInfoReturnable<Double> cir) {
        if (QolModClient.isZooming) {
            cir.setReturnValue(10.0);
        }
    }
}
