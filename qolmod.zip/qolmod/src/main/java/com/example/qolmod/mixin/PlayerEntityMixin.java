package com.example.qolmod.mixin;

import com.example.qolmod.ModConfig;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Auto-Step: Erhöht Stufenhöhe auf 1.0f wenn aktiviert (Standard: 0.6f).
 * Prüft bei jedem Tick die Config, damit Änderungen im Menü sofort wirken.
 */
@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin {

    @Shadow protected float stepHeight;

    @Inject(method = "tick", at = @At("HEAD"))
    private void qolmod$applyStepHeight(CallbackInfo ci) {
        this.stepHeight = ModConfig.get().autoStep ? 1.0f : 0.6f;
    }
}
