package com.example.qolmod.mixin;

import com.example.qolmod.ModConfig;
import net.minecraft.entity.player.HungerManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Langsamerer Hunger: Erschöpfung wird um 50% reduziert wenn aktiviert.
 */
@Mixin(HungerManager.class)
public abstract class HungerManagerMixin {

    @Shadow private float exhaustionLevel;

    @Inject(method = "addExhaustion", at = @At("HEAD"), cancellable = true)
    private void qolmod$slowerHunger(float exhaustion, CallbackInfo ci) {
        if (!ModConfig.get().slowerHunger) return;
        this.exhaustionLevel = Math.min(40.0f, this.exhaustionLevel + exhaustion * 0.5f);
        ci.cancel();
    }
}
