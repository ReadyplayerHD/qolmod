package com.example.qolmod;

import net.minecraft.block.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Auto-Replant: Wenn eine vollständig gewachsene Pflanze geerntet wird,
 * wird sie automatisch mit einem Samen aus dem Inventar neu gepflanzt.
 *
 * Unterstützte Pflanzen: Weizen, Karotten, Kartoffeln, Rüben
 */
public class AutoReplant {

    public static void tryReplant(World world, PlayerEntity player, BlockPos pos, BlockState brokenState) {
        if (!(world instanceof ServerWorld)) return;

        Block block = brokenState.getBlock();

        // Nur CropBlocks (Weizen, Karotten, etc.)
        if (!(block instanceof CropBlock cropBlock)) return;

        // Nur wenn die Pflanze vollständig gewachsen war
        if (!cropBlock.isMature(brokenState)) return;

        // Ackerboden muss noch darunter sein
        if (!world.getBlockState(pos.down()).isOf(Blocks.FARMLAND)) return;

        // Passenden Samen finden
        Item seedItem = getSeedItem(block);
        if (seedItem == null) return;

        // Samen im Spieler-Inventar suchen
        PlayerInventory inv = player.getInventory();
        int seedSlot = findItemSlot(inv, seedItem);
        if (seedSlot == -1) return; // Keine Samen → kein Replant

        // Neu pflanzen & einen Samen verbrauchen
        world.setBlockState(pos, block.getDefaultState());
        inv.getStack(seedSlot).decrement(1);
    }

    /** Gibt das Samen-Item für den jeweiligen Acker-Block zurück. */
    private static Item getSeedItem(Block cropBlock) {
        if (cropBlock == Blocks.WHEAT)     return Items.WHEAT_SEEDS;
        if (cropBlock == Blocks.CARROTS)   return Items.CARROT;
        if (cropBlock == Blocks.POTATOES)  return Items.POTATO;
        if (cropBlock == Blocks.BEETROOTS) return Items.BEETROOT_SEEDS;
        return null;
    }

    /** Sucht einen Inventar-Slot mit dem angegebenen Item. */
    private static int findItemSlot(PlayerInventory inv, Item item) {
        for (int i = 0; i < inv.size(); i++) {
            ItemStack stack = inv.getStack(i);
            if (!stack.isEmpty() && stack.isOf(item)) return i;
        }
        return -1;
    }
}
