package com.example.qolmod;

import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import java.util.*;

/**
 * Tree Feller: Wenn ein Spieler mit einer Axt einen Baumstamm bricht,
 * werden alle verbundenen Stämme automatisch mitgefällt.
 *
 * Funktioniert mit allen Holzarten (vanilla + Modded, sofern sie den
 * BlockTag #minecraft:logs haben).
 */
public class TreeFeller {

    /** Maximale Anzahl Stämme, die pro Baum gefällt werden (verhindert Lag bei riesigen Bäumen). */
    private static final int MAX_LOGS = 150;

    public static void tryFell(ServerWorld world, PlayerEntity player, BlockPos startPos, BlockState startState) {
        // Nur Stämme
        if (!startState.isIn(BlockTags.LOGS)) return;

        // Spieler muss eine Axt halten
        ItemStack tool = player.getMainHandStack();
        if (!(tool.getItem() instanceof AxeItem)) return;

        // ── BFS durch alle verbundenen Stämme ──────────────────────────
        List<BlockPos> toBreak = new ArrayList<>();
        Set<BlockPos> visited  = new HashSet<>();
        Deque<BlockPos> queue  = new ArrayDeque<>();

        queue.add(startPos);
        visited.add(startPos);

        while (!queue.isEmpty() && toBreak.size() < MAX_LOGS) {
            BlockPos current = queue.poll();
            BlockState state = world.getBlockState(current);

            if (!state.isIn(BlockTags.LOGS)) continue;

            if (!current.equals(startPos)) {
                toBreak.add(current); // startPos wurde schon von Minecraft gebrochen
            }

            // Alle 26 Nachbarn prüfen (inkl. Diagonale)
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = 0; dy <= 1; dy++) { // Nur aufwärts & gleiche Ebene
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        BlockPos neighbor = current.add(dx, dy, dz);
                        if (!visited.contains(neighbor)) {
                            visited.add(neighbor);
                            queue.add(neighbor);
                        }
                    }
                }
            }
        }

        // ── Alle gefundenen Stämme brechen ─────────────────────────────
        for (BlockPos logPos : toBreak) {
            if (tool.isEmpty()) break; // Axt kaputt → aufhören

            world.breakBlock(logPos, true, player);

            // Axt-Haltbarkeit verbrauchen (1 pro Stamm)
            if (tool.isDamageable()) {
                tool.damage(1, player, p -> p.sendToolBreakStatus(player.getActiveHand()));
            }
        }
    }
}
