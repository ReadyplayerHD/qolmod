package com.example.qolmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.Path;

/**
 * Alle Feature-Einstellungen – wird als JSON unter
 * .minecraft/config/qolmod.json gespeichert.
 */
public class ModConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("qolmod.json");

    // ── HUD ────────────────────────────────────────────────────────────────
    public boolean coordinatesHud  = true;
    public boolean statusEffectHud = true;

    // ── Komfort ────────────────────────────────────────────────────────────
    public boolean zoom            = true;
    public boolean fullbright      = false;
    public boolean fasterEating    = true;
    public boolean autoStep        = true;

    // ── Gameplay ───────────────────────────────────────────────────────────
    public boolean treeFeller      = true;
    public boolean autoReplant     = true;
    public boolean slowerHunger    = true;
    public boolean softLanding     = true;

    // ── Singleton ──────────────────────────────────────────────────────────
    private static ModConfig instance;

    public static ModConfig get() {
        if (instance == null) load();
        return instance;
    }

    public static void load() {
        File file = CONFIG_PATH.toFile();
        if (file.exists()) {
            try (Reader reader = new FileReader(file)) {
                instance = GSON.fromJson(reader, ModConfig.class);
                if (instance == null) instance = new ModConfig();
            } catch (IOException e) {
                QolMod.LOGGER.error("[QoL Mod] Config konnte nicht geladen werden: ", e);
                instance = new ModConfig();
            }
        } else {
            instance = new ModConfig();
            save();
        }
    }

    public static void save() {
        try {
            File file = CONFIG_PATH.toFile();
            file.getParentFile().mkdirs();
            try (Writer writer = new FileWriter(file)) {
                GSON.toJson(instance, writer);
            }
        } catch (IOException e) {
            QolMod.LOGGER.error("[QoL Mod] Config konnte nicht gespeichert werden: ", e);
        }
    }
}
