package com.example.qolmod;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/**
 * In-Game Einstellungsmenü der QoL Mod.
 * Öffnen mit Taste P (umstellbar in Einstellungen → Steuerung).
 *
 * Features sind in drei Kategorien aufgeteilt:
 *  • HUD        – Anzeigen auf dem Bildschirm
 *  • Komfort    – Spielverbesserungen ohne Gameplay-Einfluss
 *  • Gameplay   – Features die das Spiel aktiv verändern
 */
@Environment(EnvType.CLIENT)
public class ModConfigScreen extends Screen {

    // ── Layout ─────────────────────────────────────────────────────────────
    private static final int PANEL_W   = 350;
    private static final int ROW_H     = 24;
    private static final int BTN_W     = 64;
    private static final int BTN_H     = 18;
    private static final int PADDING   = 14;
    private static final int TITLE_H   = 28;
    private static final int CAT_H     = 18; // Kategorie-Header-Höhe

    // ── Farben ─────────────────────────────────────────────────────────────
    private static final int C_BG        = 0xF00D0D18;
    private static final int C_BORDER    = 0xFF1E3A6E;
    private static final int C_ACCENT    = 0xFF3D6FCC;
    private static final int C_TITLE     = 0xFF99CCFF;
    private static final int C_LABEL     = 0xFFDDDDDD;
    private static final int C_CAT       = 0xFF6699CC;
    private static final int C_CAT_BG    = 0xFF111827;
    private static final int C_ROW_ALT   = 0x0CFFFFFF;
    private static final int C_DIVIDER   = 0xFF1A2640;
    private static final int C_FOOTER    = 0xFF445566;

    private final Screen parent;
    private final List<FeatureLabel> labels = new ArrayList<>();

    // ── Kategorie-Daten: {Anzeigename, Icon} ──────────────────────────────
    private static final String[] CATS = { "HUD", "Komfort", "Gameplay" };

    public ModConfigScreen(Screen parent) {
        super(Text.literal("✦  QoL Mod  –  Einstellungen"));
        this.parent = parent;
    }

    // ══════════════════════════════════════════════════════════════════════
    //  INIT
    // ══════════════════════════════════════════════════════════════════════

    @Override
    protected void init() {
        super.init();
        labels.clear();

        ModConfig cfg = ModConfig.get();

        // Gesamthöhe berechnen:
        // 3 Kategorien × (CAT_H + rows × ROW_H) + TITLE_H + Footer
        int totalRows   = 2 + 4 + 4; // 2 HUD, 4 Komfort, 4 Gameplay
        int totalCats   = 3;
        int contentH    = TITLE_H + totalCats * CAT_H + totalRows * ROW_H + 36;
        int panelH      = Math.min(contentH, this.height - 20);

        int px = (this.width  - PANEL_W) / 2;
        int py = (this.height - panelH)  / 2;
        int lx = px + PADDING;
        int bx = px + PANEL_W - BTN_W - PADDING;

        int y = py + TITLE_H + 4;

        // ── HUD ──────────────────────────────────────────────────────────
        y = addCategory("◈  HUD", px, y);
        y = addToggle("🗺  Koordinaten-HUD",   "X/Y/Z + Richtung", lx, y, bx,
                () -> cfg.coordinatesHud,  v -> cfg.coordinatesHud  = v);
        y = addToggle("🧪  Statuseffekt-HUD",  "Tränke mit Restzeit", lx, y, bx,
                () -> cfg.statusEffectHud, v -> cfg.statusEffectHud = v);

        // ── Komfort ───────────────────────────────────────────────────────
        y = addCategory("◈  Komfort", px, y + 2);
        y = addToggle("💡  Fullbright  [G]",   "Volle Helligkeit per Taste", lx, y, bx,
                () -> cfg.fullbright, v -> { cfg.fullbright = v; applyFullbright(v); });
        y = addToggle("🔍  Zoom  [C halten]",  "FOV auf 10° zoomen", lx, y, bx,
                () -> cfg.zoom,            v -> cfg.zoom            = v);
        y = addToggle("🍖  Schnelles Essen",   "Halbe Essenszeit", lx, y, bx,
                () -> cfg.fasterEating,    v -> cfg.fasterEating    = v);
        y = addToggle("👟  Auto-Step",         "1 Block ohne springen", lx, y, bx,
                () -> cfg.autoStep,        v -> cfg.autoStep        = v);

        // ── Gameplay ──────────────────────────────────────────────────────
        y = addCategory("◈  Gameplay", px, y + 2);
        y = addToggle("🌳  Tree Feller",       "Axt fällt ganze Bäume", lx, y, bx,
                () -> cfg.treeFeller,      v -> cfg.treeFeller      = v);
        y = addToggle("🌾  Auto-Replant",      "Ernte pflanzt sich neu", lx, y, bx,
                () -> cfg.autoReplant,     v -> cfg.autoReplant     = v);
        y = addToggle("🍗  Langsamer Hunger",  "50% weniger Erschöpfung", lx, y, bx,
                () -> cfg.slowerHunger,    v -> cfg.slowerHunger    = v);
        y = addToggle("🪂  Weiche Landung",    "Max 10 Herzen Fallschaden", lx, y, bx,
                () -> cfg.softLanding,     v -> cfg.softLanding     = v);

        // ── Speichern-Button ──────────────────────────────────────────────
        int closeBtnW = 190;
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("✔  Speichern & Schließen"),
                btn -> closeAndSave()
        ).dimensions(px + (PANEL_W - closeBtnW) / 2, y + 6, closeBtnW, 20).build());
    }

    // ══════════════════════════════════════════════════════════════════════
    //  RENDER
    // ══════════════════════════════════════════════════════════════════════

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx, mouseX, mouseY, delta);

        int px = (this.width  - PANEL_W) / 2;
        // Panel-Höhe rückberechnen
        int totalRows = 2 + 4 + 4;
        int contentH  = TITLE_H + 3 * CAT_H + totalRows * ROW_H + 36;
        int panelH    = Math.min(contentH, this.height - 20);
        int py = (this.height - panelH) / 2;

        // Hintergrund
        ctx.fill(px, py, px + PANEL_W, py + panelH, C_BG);

        // Rand
        ctx.fill(px,            py,              px + PANEL_W, py + 1,         C_BORDER);
        ctx.fill(px,            py + panelH - 1, px + PANEL_W, py + panelH,    C_BORDER);
        ctx.fill(px,            py,              px + 1,        py + panelH,    C_BORDER);
        ctx.fill(px + PANEL_W - 1, py,           px + PANEL_W, py + panelH,    C_BORDER);

        // Titelleiste
        ctx.fill(px + 1, py + 1, px + PANEL_W - 1, py + TITLE_H, 0xFF0A0E18);
        ctx.fill(px + 1, py + TITLE_H - 2, px + PANEL_W - 1, py + TITLE_H - 1, C_ACCENT);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title,
                this.width / 2, py + (TITLE_H - this.textRenderer.fontHeight) / 2, C_TITLE);

        // Kategorie-Labels & Trennlinien (aus labels-Liste)
        for (FeatureLabel fl : labels) {
            if (fl.isCategory()) {
                ctx.fill(px + 1, fl.y() - 2, px + PANEL_W - 1, fl.y() + CAT_H - 2, C_CAT_BG);
                ctx.fill(px + PADDING, fl.y() + CAT_H - 3,
                         px + PANEL_W - PADDING, fl.y() + CAT_H - 2, C_ACCENT);
                ctx.drawTextWithShadow(this.textRenderer, Text.literal(fl.text()),
                        fl.x(), fl.y() + 2, C_CAT);
            } else {
                ctx.drawTextWithShadow(this.textRenderer, Text.literal(fl.text()),
                        fl.x(), fl.y(), C_LABEL);
                // Beschreibung eine Zeile tiefer in grau
                if (fl.desc() != null) {
                    ctx.drawTextWithShadow(this.textRenderer, Text.literal("§8" + fl.desc()),
                            fl.x() + 1, fl.y() + 10, 0xFF666688);
                }
            }
        }

        // Widgets (Buttons)
        super.render(ctx, mouseX, mouseY, delta);

        // Fußzeile
        ctx.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("§8config/qolmod.json  ·  Taste P zum Öffnen/Schließen"),
                this.width / 2, py + panelH - 12, C_FOOTER);
    }

    // ══════════════════════════════════════════════════════════════════════
    //  HILFSMETHODEN
    // ══════════════════════════════════════════════════════════════════════

    /** Fügt eine Kategorie-Überschrift ein und gibt die neue Y-Position zurück. */
    private int addCategory(String name, int panelX, int y) {
        labels.add(new FeatureLabel(name, panelX + PADDING, y, null, true));
        return y + CAT_H;
    }

    /** Fügt eine Feature-Reihe mit Label + Toggle-Button ein. */
    private int addToggle(String name, String desc, int lx, int y, int bx,
                          BooleanSupplier getter, Consumer<Boolean> setter) {
        labels.add(new FeatureLabel(name, lx, y, desc, false));

        this.addDrawableChild(ButtonWidget.builder(
                toggleText(getter.getAsBoolean()),
                btn -> {
                    boolean next = !getter.getAsBoolean();
                    setter.accept(next);
                    btn.setMessage(toggleText(next));
                }
        ).dimensions(bx, y - 1, BTN_W, BTN_H).build());

        return y + ROW_H;
    }

    private static Text toggleText(boolean on) {
        return on ? Text.literal("§a● AN") : Text.literal("§c○ AUS");
    }

    private void applyFullbright(boolean enabled) {
        if (this.client == null) return;
        if (enabled) {
            QolModClient.savedGamma = this.client.options.getGamma().getValue();
            this.client.options.getGamma().setValue(16.0);
        } else {
            this.client.options.getGamma().setValue(QolModClient.savedGamma);
        }
    }

    private void closeAndSave() {
        ModConfig.save();
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override public void close()           { closeAndSave(); }
    @Override public boolean shouldPause()  { return false; }

    // ── Datensatz für Label-Einträge ───────────────────────────────────────
    private record FeatureLabel(String text, int x, int y, String desc, boolean isCategory) {}
}
