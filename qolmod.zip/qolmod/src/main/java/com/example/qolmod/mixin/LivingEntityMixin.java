package com.example.qolmod.mixin;

import com.example.qolmod.ModConfig;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Weiche Landung: Fallschaden auf max. 20 HP (10 Herzen) begrenzt.
 * Beim Schleichen: Schaden wird zusätzlich halbiert.
 */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {

    @Inject(method = "handleFallDamage", at = @At("HEAD"), cancellable = true)
    private void qolmod$softLanding(float fallDistance, float damageMultiplier,
                                    DamageSource source, CallbackInfoReturnable<Boolean> cir) {
        if (!ModConfig.get().softLanding) return;

        LivingEntity self = (LivingEntity)(Object)this;
        if (!(self instanceof PlayerEntity player)) return;

        float effectiveFall = fallDistance - 3.0f;
        if (effectiveFall <= 0) return;

        float damage = effectiveFall * damageMultiplier;
        if (player.isSneaking()) damage *= 0.5f;
        damage = Math.min(damage, 20.0f);

        player.damage(source, damage);
        cir.setReturnValue(true);
    }
}
