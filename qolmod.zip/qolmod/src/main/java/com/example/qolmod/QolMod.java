package com.example.qolmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class QolMod implements ModInitializer {

    public static final String MOD_ID = "qolmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModConfig.load();
        registerBlockBreakEvents();
        LOGGER.info("[QoL Mod] Geladen! Drücke P für die Einstellungen.");
    }

    /**
     * Server-seitige Block-Break Events für Tree Feller & Auto-Replant.
     * Läuft auf dem Server (auch im Singleplayer-Integrated-Server).
     */
    private void registerBlockBreakEvents() {
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            ModConfig cfg = ModConfig.get();

            if (cfg.treeFeller) {
                TreeFeller.tryFell(world, player, pos, state);
            }

            if (cfg.autoReplant) {
                AutoReplant.tryReplant(world, player, pos, state);
            }
        });
    }
}
