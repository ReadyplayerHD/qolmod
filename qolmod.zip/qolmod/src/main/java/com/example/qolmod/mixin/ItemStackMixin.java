package com.example.qolmod.mixin;

import com.example.qolmod.ModConfig;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ItemStack.class)
public abstract class ItemStackMixin {
    @Inject(method = "getMaxUseTime", at = @At("RETURN"), cancellable = true)
    private void qolmod$fasterEating(CallbackInfoReturnable<Integer> cir) {
        if (ModConfig.get().fasterEating && cir.getReturnValue() == 32) {
            cir.setReturnValue(16);
        }
    }
}
